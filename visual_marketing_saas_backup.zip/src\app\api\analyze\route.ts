import { NextResponse } from 'next/server';
import { openai } from '@/lib/openai';
import { AnalysisResult } from '@/types';

export async function POST(req: Request) {
    try {
        const { image } = await req.json();

        if (!image) {
            return NextResponse.json({ error: 'No image provided' }, { status: 400 });
        }

        const prompt = `
      You are a world-class Visual Marketing Expert. Analyze this image for marketing effectiveness.
      Target audience: General social media users (Instagram/TikTok/LinkedIn).
      
      Provide a structured analysis in JSON format with the following fields:
      - score: A number between 0-100 representing overall marketing impact.
      - summary: A concise 2-sentence summary of the visual's effectiveness.
      - strengths: Array of 3 key strengths.
      - weaknesses: Array of 3 key weaknesses.
      - recommendations: Array of objects with { category: 'style'|'content'|'structure'|'color', suggestion: string, impact: 'high'|'medium'|'low' }.
      - platformSpecifics: Object with { platform: 'instagram'|'tiktok'|'youtube', tips: string[] } (Choose the most relevant platform).

      Focus on:
      - Visual hierarchy and clarity
      - Color psychology and branding
      - Text readability and hook (if any)
      - Emotional appeal and engagement potential
    `;

        const response = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: [
                {
                    role: "user",
                    content: [
                        { type: "text", text: prompt },
                        {
                            type: "image_url",
                            image_url: {
                                url: image, // Expecting base64 data URL
                            },
                        },
                    ],
                },
            ],
            response_format: { type: "json_object" },
            max_tokens: 1000,
        });

        const content = response.choices[0].message.content;
        if (!content) {
            throw new Error('No content received from OpenAI');
        }

        const analysis: AnalysisResult = JSON.parse(content);
        return NextResponse.json(analysis);

    } catch (error) {
        console.error('Analysis error:', error);
        return NextResponse.json(
            { error: 'Failed to analyze image' },
            { status: 500 }
        );
    }
}
