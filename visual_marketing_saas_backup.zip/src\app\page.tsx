'use client';

import React, { useState } from 'react';
import { UploadZone } from '@/components/upload-zone';
import { AnalysisResults } from '@/components/analysis-results';
import { AnalysisResult } from '@/types';
import { Loader2 } from 'lucide-react';

export default function Home() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      // Convert to base64
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64 = reader.result as string;

        const response = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64 }),
        });

        if (!response.ok) {
          throw new Error('Analysis failed');
        }

        const data = await response.json();
        setResult(data);
        setIsAnalyzing(false);
      };
      reader.onerror = () => {
        setError('Failed to read file');
        setIsAnalyzing(false);
      };
    } catch (err) {
      setError('An error occurred during analysis. Please try again.');
      setIsAnalyzing(false);
    }
  };

  return (
    <main className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 p-8">
      <div className="max-w-5xl mx-auto space-y-12">

        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Visual Marketing AI
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Upload your content and get instant, actionable marketing feedback to boost your engagement.
          </p>
        </div>

        {/* Upload Section */}
        <div className="space-y-8">
          <UploadZone onFileSelect={handleFileSelect} isAnalyzing={isAnalyzing} />

          {isAnalyzing && (
            <div className="flex flex-col items-center justify-center space-y-4 py-12 animate-in fade-in">
              <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
              <p className="text-lg font-medium text-gray-600 dark:text-gray-400">
                Analyzing your content...
              </p>
              <p className="text-sm text-gray-500">
                Checking visual hierarchy, color psychology, and engagement potential.
              </p>
            </div>
          )}

          {error && (
            <div className="p-4 bg-red-50 text-red-600 rounded-lg text-center">
              {error}
            </div>
          )}

          {result && <AnalysisResults result={result} />}
        </div>
      </div>
    </main>
  );
}
