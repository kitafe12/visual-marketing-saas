'use client';

import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X, FileImage, FileVideo } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface UploadZoneProps {
    onFileSelect: (file: File) => void;
    isAnalyzing?: boolean;
}

export function UploadZone({ onFileSelect, isAnalyzing }: UploadZoneProps) {
    const [preview, setPreview] = useState<string | null>(null);
    const [fileType, setFileType] = useState<'image' | 'video' | null>(null);

    const onDrop = useCallback((acceptedFiles: File[]) => {
        const file = acceptedFiles[0];
        if (file) {
            const objectUrl = URL.createObjectURL(file);
            setPreview(objectUrl);
            setFileType(file.type.startsWith('video') ? 'video' : 'image');
            onFileSelect(file);
        }
    }, [onFileSelect]);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            'image/*': ['.png', '.jpg', '.jpeg', '.webp'],
            'video/*': ['.mp4', '.mov']
        },
        maxFiles: 1,
        disabled: isAnalyzing
    });

    const clearFile = (e: React.MouseEvent) => {
        e.stopPropagation();
        setPreview(null);
        setFileType(null);
    };

    return (
        <div className="w-full max-w-2xl mx-auto">
            <div
                {...getRootProps()}
                className={cn(
                    "relative border-2 border-dashed rounded-xl p-10 transition-all duration-200 ease-in-out cursor-pointer",
                    isDragActive ? "border-blue-500 bg-blue-50/10" : "border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600",
                    preview ? "border-solid border-blue-500" : ""
                )}
            >
                <input {...getInputProps()} />

                {preview ? (
                    <div className="relative flex flex-col items-center justify-center">
                        <Button
                            variant="destructive"
                            size="icon"
                            className="absolute -top-4 -right-4 z-10 rounded-full"
                            onClick={clearFile}
                        >
                            <X className="h-4 w-4" />
                        </Button>

                        {fileType === 'image' ? (
                            <img
                                src={preview}
                                alt="Preview"
                                className="max-h-[400px] rounded-lg shadow-lg object-contain"
                            />
                        ) : (
                            <video
                                src={preview}
                                controls
                                className="max-h-[400px] rounded-lg shadow-lg"
                            />
                        )}
                        <p className="mt-4 text-sm text-gray-500">Click or drag to replace</p>
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center text-center space-y-4">
                        <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-full">
                            <Upload className="h-8 w-8 text-gray-500" />
                        </div>
                        <div>
                            <p className="text-lg font-medium">
                                {isDragActive ? "Drop the file here" : "Drag & drop your content here"}
                            </p>
                            <p className="text-sm text-gray-500 mt-1">
                                Supports JPG, PNG, WEBP, MP4
                            </p>
                        </div>
                        <Button variant="outline" type="button">
                            Select File
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
}
