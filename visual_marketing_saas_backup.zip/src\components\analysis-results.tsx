import React, { useState } from 'react';
import { AnalysisResult } from '@/types';
import { CheckCircle, XCircle, Lightbulb, TrendingUp, Copy, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface AnalysisResultsProps {
    result: AnalysisResult;
}

export function AnalysisResults({ result }: AnalysisResultsProps) {
    const [copied, setCopied] = useState(false);

    const getScoreColor = (score: number) => {
        if (score >= 80) return 'text-green-500 border-green-500';
        if (score >= 60) return 'text-yellow-500 border-yellow-500';
        return 'text-red-500 border-red-500';
    };

    const handleCopy = () => {
        const text = `
Visual Marketing Analysis
Score: ${result.score}/100
Summary: ${result.summary}

Strengths:
${result.strengths.map(s => `- ${s}`).join('\n')}

Weaknesses:
${result.weaknesses.map(w => `- ${w}`).join('\n')}

Recommendations:
${result.recommendations.map(r => `- [${r.impact}] ${r.suggestion}`).join('\n')}
    `.trim();

        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="w-full max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">

            {/* Header / Score */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 bg-white dark:bg-gray-900 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                <div className="flex-1">
                    <div className="flex items-center gap-4 mb-2">
                        <h2 className="text-2xl font-bold">Analysis Complete</h2>
                        <Button variant="outline" size="sm" onClick={handleCopy} className="gap-2">
                            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                            {copied ? 'Copied' : 'Copy Report'}
                        </Button>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300">{result.summary}</p>
                </div>
                <div className={cn(
                    "flex items-center justify-center w-24 h-24 rounded-full border-4 text-3xl font-bold",
                    getScoreColor(result.score)
                )}>
                    {result.score}
                </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                {/* Strengths */}
                <div className="p-6 bg-green-50/50 dark:bg-green-900/10 rounded-xl border border-green-100 dark:border-green-900/20">
                    <h3 className="flex items-center gap-2 text-lg font-semibold text-green-700 dark:text-green-400 mb-4">
                        <CheckCircle className="w-5 h-5" /> Strengths
                    </h3>
                    <ul className="space-y-3">
                        {result.strengths.map((item, i) => (
                            <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-green-500 shrink-0" />
                                {item}
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Weaknesses */}
                <div className="p-6 bg-red-50/50 dark:bg-red-900/10 rounded-xl border border-red-100 dark:border-red-900/20">
                    <h3 className="flex items-center gap-2 text-lg font-semibold text-red-700 dark:text-red-400 mb-4">
                        <XCircle className="w-5 h-5" /> Areas for Improvement
                    </h3>
                    <ul className="space-y-3">
                        {result.weaknesses.map((item, i) => (
                            <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                                {item}
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            {/* Recommendations */}
            <div className="p-6 bg-white dark:bg-gray-900 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                <h3 className="flex items-center gap-2 text-lg font-semibold mb-6">
                    <Lightbulb className="w-5 h-5 text-yellow-500" /> Strategic Recommendations
                </h3>
                <div className="grid gap-4">
                    {result.recommendations.map((rec, i) => (
                        <div key={i} className="flex items-start gap-4 p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                            <div className={cn(
                                "px-2 py-1 rounded text-xs font-medium uppercase tracking-wider",
                                rec.impact === 'high' ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400" :
                                    rec.impact === 'medium' ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400" :
                                        "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                            )}>
                                {rec.impact} Impact
                            </div>
                            <div>
                                <span className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase mr-2">
                                    {rec.category}
                                </span>
                                <p className="text-gray-900 dark:text-gray-100 mt-1">{rec.suggestion}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Platform Specifics */}
            {result.platformSpecifics && (
                <div className="p-6 bg-blue-50/50 dark:bg-blue-900/10 rounded-xl border border-blue-100 dark:border-blue-900/20">
                    <h3 className="flex items-center gap-2 text-lg font-semibold text-blue-700 dark:text-blue-400 mb-4">
                        <TrendingUp className="w-5 h-5" /> {result.platformSpecifics.platform.charAt(0).toUpperCase() + result.platformSpecifics.platform.slice(1)} Optimization
                    </h3>
                    <ul className="space-y-3">
                        {result.platformSpecifics.tips.map((tip, i) => (
                            <li key={i} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                                {tip}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
}
